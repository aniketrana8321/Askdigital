
<!DOCTYPE html>
<html  lang="">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">

    <title >ASK Digital Agency CMS</title>
    <meta name="description" content="Desix | Multipurpose Business, Creative &amp; Digital Agency CMS">
    
    <link rel="shortcut icon" href="https://askdigitalagency.com/wp-content/uploads/2024/04/Artboard-7-copy-2.png.webp" type="image/x-icon">
    <link rel="icon" href="https://askdigitalagency.com/wp-content/uploads/2024/04/Artboard-7-copy-2.png.webp" type="image/x-icon">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fontawesome-iconpicker/3.2.0/css/fontawesome-iconpicker.min.css">
    <link rel="stylesheet" href="https://cdn.flaticon.com/path-to-your-icons.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
<!-- Owl Carousel CSS -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css">
<!-- Fancybox CSS -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.7/jquery.fancybox.min.css" />

<!-- Fancybox JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.7/jquery.fancybox.min.js"></script>

    <!-- Stylesheets -->
<link href="https://demo.phpscriptpoint.com/desix/public/dist-front/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="{{ asset('front-end/style.css') }}">
<style>
    .preloader:after {
        background-image: url(https://demo.phpscriptpoint.com/desix/public/uploads/favicon_1699434586.png);
    }
    .dark-layout .preloader:after {
        background-image: url(https://demo.phpscriptpoint.com/desix/public/uploads/logo_1699436212.png);
    }
</style>
    
    
    
    
        <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-84213520-6"></script>
    <script>
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());

        gtag('config', 'UA-84213520-6');
    </script>
    
    <style >
    :root {
        --theme-color1: #FEC63F;
    }
    </style>

</head>

<body>

    <div class="page-wrapper">
        
                
        <!-- Main Header-->
        <header class="main-header header-style-two">
            
            <!-- Header Top -->
<div class="header-top">
    <div class="inner-container">

        <div class="top-left">
            <!-- Info List -->
            <ul class="list-style-one">
                                <li ><i class="fa fa-envelope"></i> <a href="mailto:needhelp@company.com">needhelp@company.com</a></li>
                
                                <li ><i class="fa fa-map-marker"></i> 88 Broklyn Golden Street. New York</li>
                            </ul>
        </div>

        <div class="top-right">
            <ul class="useful-links">
                <li ><a href="https://demo.phpscriptpoint.com/desix/about">About</a></li>
                <li ><a href="https://demo.phpscriptpoint.com/desix/faq">FAQ</a></li>
                <li ><a href="https://demo.phpscriptpoint.com/desix/contact">Contact</a></li>
            </ul>

                        <ul class="social-icon-one">
                                <li ><a href="#"><span class="fab fa-twitter"></span></a></li>
                
                                <li ><a href="#"><span class="fab fa-facebook-f"></span></a></li>
                
                
                                <li ><a href="#"><span class="fab fa-instagram"></span></a></li>
                
                
                                <li ><a href="#"><span class="fab fa-pinterest-p"></span></a></li>
                            </ul>
                    </div>
    </div>
</div>
<!-- Header Top -->            
            <div class="header-lower">
                <!-- Main box -->
                <div class="main-box">
                <div class="logo-box">
                @php
    use App\Models\WebsiteSetting;
    $settings = WebsiteSetting::first();
@endphp

<div class="logo">
    <a href="{{ url('/') }}">
        <img src="{{ asset('storage/' . ($settings->logo ?? 'default-logo.png')) }}" alt="Desix">
    </a>
</div>

</div>


                    <!--Nav Box-->
                    <div class="nav-outer">    
                        <nav class="nav main-menu">
                            <ul class="navigation">

                                                                <li class="current dropdown"><a href="javascript:;">Home</a>
                                    <ul >
                                        <li ><a href="https://demo.phpscriptpoint.com/desix/home/layout/1">Home Layout 1</a></li>
                                        <li ><a href="https://demo.phpscriptpoint.com/desix/home/layout/2">Home Layout 2</a></li>
                                        <li ><a href="https://demo.phpscriptpoint.com/desix/home/layout/3">Home Layout 3</a></li>
                                        <li ><a href="https://demo.phpscriptpoint.com/desix/home/layout/4">Home Layout 4</a></li>
                                    </ul>
                                </li>
                                
                                
                                
                                
                                

                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                <li class="dropdown"><a href="javascript:;">Pages</a>
                                    <ul >
                                                                                <li ><a href="https://demo.phpscriptpoint.com/desix/about">About Us</a></li>
                                        
                                                                                <li ><a href="https://demo.phpscriptpoint.com/desix/team-members">Team</a></li>
                                        
                                                                                <li ><a href="https://demo.phpscriptpoint.com/desix/testimonials">Testimonial</a></li>
                                        
                                                                                <li ><a href="https://demo.phpscriptpoint.com/desix/pricing">Pricing</a></li>
                                        
                                                                                <li ><a href="https://demo.phpscriptpoint.com/desix/faq">FAQ</a></li>
                                        
                                                                                <li ><a href="https://demo.phpscriptpoint.com/desix/page/custom-page-1">Custom Page 1</a></li>
                                                                                <li ><a href="https://demo.phpscriptpoint.com/desix/page/custom-page-2">Custom Page 2</a></li>
                                                                            </ul>
                                </li>

                                                                <li class="">
                                    <a href="https://demo.phpscriptpoint.com/desix/services">Services</a>
                                </li>
                                
                                                                <li class="">
                                    <a href="https://demo.phpscriptpoint.com/desix/portfolios">Portfolio</a>
                                </li>
                                
                                                                <li class="">
                                    <a href="https://demo.phpscriptpoint.com/desix/blog">Blog</a>
                                </li>
                                
                                                                <li class="">
                                    <a href="https://demo.phpscriptpoint.com/desix/contact">Contact</a>
                                </li>
                                                                
                                                                                                <li class="lang">
                                    <img class="globe" src="https://demo.phpscriptpoint.com/desix/public/uploads/globe.png" alt="">
                                    <img class="globe-black" src="https://demo.phpscriptpoint.com/desix/public/uploads/globe-black.png" alt="">
                                    <form action="https://demo.phpscriptpoint.com/desix/language-switch" method="post">
                                        <input type="hidden" name="_token" value="leEeYbKwm3HoZH5MXgcVygjvnfuvKDXR2aI1Vwyv" autocomplete="off">                                        <select name="code" class="form-control" onchange="this.form.submit()">
                                                                                            <option value="en" >English</option>
                                                                                            <option value="ar" >Arabic</option>
                                                                                            <option value="hi" >Hindi</option>
                                                                                    </select>
                                    </form>
                                </li>
                                                                
                            </ul>
                        </nav>
                    </div>

                    <div class="outer-box">
                        <!-- Header Search -->
                        <button class="ui-btn ui-btn search-btn">
                            <span class="icon lnr lnr-icon-search"></span>
                        </button>
                                                <a href="tel:+92 (8800) - 9850" class="info-btn">
                            <i class="icon lnr-icon-phone-handset"></i>
                            <small >Call Anytime</small>
                            +92 (8800) - 9850
                        </a>
                                                <!-- Mobile Nav toggler -->
                        <div class="mobile-nav-toggler"><span class="icon lnr-icon-bars"></span></div>
                    </div>
                </div>
            </div>

            <!-- Mobile Menu  -->
            <div class="mobile-menu">
                <div class="menu-backdrop"></div>
            
                <!--Here Menu Will Come Automatically Via Javascript / Same Menu as in Header-->
                <nav class="menu-box">
                    <div class="upper-box">
                        <div class="nav-logo"><a href="https://demo.phpscriptpoint.com/desix"><img src="https://askdigitalagency.com/wp-content/uploads/2024/04/Artboard-7-copy-2.png.webp" alt="Desix" title=""></a></div>
                        <div class="close-btn"><i class="icon fa fa-times"></i></div>
                    </div>
            
                    <ul class="navigation clearfix">
                        <!--Keep This Empty / Menu will come through Javascript-->
                    </ul>

                                        <ul class="contact-list-one">
                                                <li >
                            <!-- Contact Info Box -->
                            <div class="contact-info-box">
                                <i class="icon lnr-icon-phone-handset"></i>
                                <span class="title">Call Now</span>
                                <a href="tel:+92 (8800) - 9850">+92 (8800) - 9850</a>
                            </div>
                        </li>
                                                                        <li >
                            <!-- Contact Info Box -->
                            <div class="contact-info-box">
                                <span class="icon lnr-icon-envelope1"></span>
                                <span class="title">Send Email</span>
                                <a href="mailto:needhelp@company.com">needhelp@company.com</a>
                            </div>
                        </li>
                                            </ul>
                    
                                        <ul class="social-links">
                                                <li ><a href="#"><i class="fab fa-twitter"></i></a></li>
                        
                                                <li ><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                        
                        
                                                <li ><a href="#"><i class="fab fa-instagram"></i></a></li>
                        
                        
                                                <li ><a href="#"><i class="fab fa-pinterest-p"></i></a></li>
                                            </ul>
                                    </nav>
            </div><!-- End Mobile Menu -->

            <!-- Header Search -->
            <div class="search-popup">
                <span class="search-back-drop"></span>
                <button class="close-search"><span class="fa fa-times"></span></button>
            
                <div class="search-inner">
                    <form method="get" action="https://demo.phpscriptpoint.com/desix/search">
                        <div class="form-group">
                            <input type="search" name="search_text" value="" placeholder="Search..." required>
                            <button type="submit"><i class="fa fa-search"></i></button>
                        </div>
                    </form>
                </div>
            </div>
            <!-- End Header Search -->

            <!-- Sticky Header  -->
            <div class="sticky-header">
                <div class="auto-container">
                    <div class="inner-container">
                        <!--Logo-->
                        <div class="logo">
                            <a href="https://demo.phpscriptpoint.com/desix">
                                                                    <img src="https://askdigitalagency.com/wp-content/uploads/2024/04/Artboard-7-copy-2.png.webp" alt="Desix">
                                                            </a>
                        </div>
            
                        <!--Right Col-->
                        <div class="nav-outer">
                            <!-- Main Menu -->
                            <nav class="main-menu">
                                <div class="navbar-collapse show collapse clearfix">
                                    <ul class="navigation clearfix">
                                        <!--Keep This Empty / Menu will come through Javascript-->
                                    </ul>
                                </div>
                            </nav><!-- Main Menu End-->
            
                            <!--Mobile Navigation Toggler-->
                            <div class="mobile-nav-toggler"><span class="icon lnr-icon-bars"></span></div>
                        </div>
                    </div>
                </div>
            </div><!-- End Sticky Menu -->
        </header>
        <!--End Main Header -->