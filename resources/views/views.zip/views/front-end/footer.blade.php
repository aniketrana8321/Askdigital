<!-- Footer Section -->
<footer class="footer">
    <div class="container">
        <div class="row">
            <!-- Services Column -->
            <div class="col-md-3">
                <h4>Services</h4>
                <a href="#">Search Engine Optimization</a>
                <a href="#">Social Media Management</a>
                <a href="#">WordPress Development</a>
                <a href="#">Ecommerce Development</a>
                <a href="#">Mobile App Development</a>
            </div>
            <div class="col-md-3">
                <h4></h4>
                <br>
                <a href="#">Digital Marketing Services</a>
                <a href="#">Shopify Development</a>
                <a href="#">Facebook Ads</a>
                <a href="#">PPC</a>
                <a href="#">Software Testing</a>
            </div>
            <!-- Useful Links Column -->
             
            <div class="col-md-3">
                <h4>Useful Links</h4>
                <a href="#">About Us</a>
                <a href="#">Blog</a>
                <a href="#">Write For Us</a>
                <a href="#">Contact Us</a>
                <a href="#">Privacy Policy</a>
            </div>

            <!-- Contact Column -->
            <div class="col-md-3">
            <h4 style="text-align: center; color: #fff;">Contact Us</h4>
                <p><i class="fas fa-phone"></i> +91 8219941967</p>
                <p><i class="fas fa-envelope"></i> agency@askdigitalagency.com</p>
                <p><i class="fas fa-map-marker-alt"></i> Ss Omnia, Sector 86, Gurugram, Haryana 122004</p>
                <div class="social-icons">
                    <a href="#"><i class="fab fa-facebook"></i></a>
                    <a href="#"><i class="fab fa-instagram"></i></a>
                    <a href="#"><i class="fab fa-linkedin"></i></a>
                </div>
            </div>
        </div>

        <hr style="border-color: rgba(255, 255, 255, 0.2); margin: 30px 0;">

        <!-- Extra Links -->
        @php
    use App\Models\InnerPage;
    $innerPages = InnerPage::latest()->get(); // ✅ Sare pages fetch karna
@endphp

<div class="row">
    @foreach ($innerPages->chunk(5) as $chunk)  {{-- ✅ 5-5 ke groups banane ke liye --}}
        <div class="col-md-4">
            @foreach ($chunk as $page)
                <a href="{{ url('/inner-page/' . $page->slug) }}">{{ $page->title }}</a>
            @endforeach
        </div>
    @endforeach
</div>

    </div>
</footer>

<!-- Footer Bottom -->
<div class="footer-bottom">
    Copyright © 2024 ASK Digital Agency. All rights reserved.
</div>

    
    <div class="scroll-to-top scroll-to-target" data-target="html"><span class="fa fa-angle-up"></span></div>
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            const counters = document.querySelectorAll(".counter-number");
            counters.forEach(counter => {
                const updateCount = () => {
                    const target = +counter.getAttribute("data-target");
                    const count = +counter.innerText;
                    const speed = 100; 
                    const increment = target / speed;
                    if (count < target) {
                        counter.innerText = Math.ceil(count + increment);
                        setTimeout(updateCount, 50);
                    } else {
                        counter.innerText = target + "+";
                    }
                };
                updateCount();
            });
        });
    </script>
    <script src="https://demo.phpscriptpoint.com/desix/public/dist-front/js/jquery-3.7.1.min.js"></script>
<script src="https://demo.phpscriptpoint.com/desix/public/dist-front/js/popper.min.js"></script>
<script src="https://demo.phpscriptpoint.com/desix/public/dist-front/js/bootstrap.min.js"></script>
<script src="https://demo.phpscriptpoint.com/desix/public/dist-front/js/jquery.fancybox.js"></script>
<script src="https://demo.phpscriptpoint.com/desix/public/dist-front/js/jquery-ui.js"></script>
<script src="https://demo.phpscriptpoint.com/desix/public/dist-front/js/jquery.countdown.js"></script>
<script src="https://demo.phpscriptpoint.com/desix/public/dist-front/js/bxslider.js"></script>
<script src="https://demo.phpscriptpoint.com/desix/public/dist-front/js/mixitup.js"></script>
<script src="https://demo.phpscriptpoint.com/desix/public/dist-front/js/wow.js"></script>
<script src="https://demo.phpscriptpoint.com/desix/public/dist-front/js/appear.js"></script>
<script src="https://demo.phpscriptpoint.com/desix/public/dist-front/js/select2.min.js"></script>
<script src="https://demo.phpscriptpoint.com/desix/public/dist-front/js/swiper.min.js"></script>
<script src="https://demo.phpscriptpoint.com/desix/public/dist-front/js/sweetalert2.min.js"></script>
<script src="https://demo.phpscriptpoint.com/desix/public/dist-front/js/owl.js"></script>
<script src="https://demo.phpscriptpoint.com/desix/public/dist-front/js/script.js"></script>


<!-- Owl Carousel JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
    
</body>
</html>