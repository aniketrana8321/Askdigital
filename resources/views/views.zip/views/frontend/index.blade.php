@include('front-end.header')






<!-- Slider Section -->
<section class="banner-section">
    <div class="banner-carousel owl-carousel owl-theme default-navs">
        @foreach($sliders as $slider)
            @if($slider->status) <!-- Sirf Active Sliders Dikhaye -->
                <div class="slide-item">
                    <div class="bg-image" style="background-image: url('{{ asset('storage/'.$slider->photo) }}');"></div>
                    <div class="auto-container">
                        <div class="content-box">
                            <h1 class="title animate-1">
                                {!! nl2br(e($slider->text)) !!}
                            </h1>
                            @if($slider->button_text)
                                <div class="btn-box animate-2">
                                    <a href="{{ $slider->button_url }}" class="theme-btn btn-style-one hover-light">
                                        <span class="btn-title">{{ $slider->button_text }}</span>
                                    </a>
                                </div>
                            @endif
                        </div>
                    </div>
                </div>
            @endif
        @endforeach
    </div>
</section>
<!-- End Slider Section -->

<div class="marquee-section">
    <div class="marquee">
        <div class="marquee-group">
            @foreach($marquees as $marquee)
            @if($slider->status)
                <div class="text">* {{ $marquee->item }}</div>
                @endif
            @endforeach
        </div>
        <div aria-hidden="true" class="marquee-group">
            @foreach($marquees as $marquee)
            @if($slider->status)
                <div class="text">* {{ $marquee->item }}</div>
                @endif
            @endforeach
        </div>
    </div>
</div>

<section class="services-section-two">
    <div class="bg bg-pattern-12"></div>
    <div class="auto-container">
        <div class="sec-title text-center light">
            <span class="sub-title">OUR SERVICES</span>
            <h2>Explore what services<br /> we're offering</h2>
        </div>
        
    
        <!-- Recently Added Services -->
        <div class="row">
            @foreach($recent_services as $service)
                <div class="service-block-two col-lg-4 col-md-6 col-sm-12 wow fadeInUp">
                    <div class="inner-box">
                        <div class="image-box">
                            <figure class="image"><img src="{{ asset('storage/' . $service->photo) }}" alt="{{ $service->name }}"></figure>
                        </div>
                        <div class="title-box">
                            <h5 class="title"><a href="{{ url('service/' . $service->slug) }}">{{ $service->name }}</a></h5>
                        </div>
                        <div class="content-box">
                            <i class="icon flaticon-technology"></i>
                            <div class="text">{{ $service->short_description }}</div>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
    </div>
</section>


<section class="rating-section">
<h2><span class="highlight-text">A Digital Marketing</span> Agency Honored for Results</h2>
        <div class="container">
          
            <div class="row mt-4">
                <!-- First Row -->
                <div class="col-md-3 col-6 mb-3">
                    <div class="rating-box">
                        <img src="https://cdn-ilbedhn.nitrocdn.com/gHPqezBpgLsaCHhGmBiaIcGAdKlxaMLv/assets/images/optimized/rev-c26d8bd/askdigitalagency.com/wp-content/uploads/2024/04/techreviewer.png" alt="Tech Reviewer">
                        <!-- <h5>Tech Reviewer</h5>
                        <div class="stars">★★★★★</div> -->
                    </div>
                </div>
                <div class="col-md-3 col-6 mb-3">
                    <div class="rating-box">
                        <img src="https://cdn-ilbedhn.nitrocdn.com/gHPqezBpgLsaCHhGmBiaIcGAdKlxaMLv/assets/images/optimized/rev-c26d8bd/askdigitalagency.com/wp-content/uploads/2024/04/techreviewer.png" alt="Clutch">
                        <!-- <h5>Clutch</h5>
                        <div class="stars">★★★★★</div> -->
                    </div>
                </div>
                <div class="col-md-3 col-6 mb-3">
                    <div class="rating-box">
                        <img src="https://cdn-ilbedhn.nitrocdn.com/gHPqezBpgLsaCHhGmBiaIcGAdKlxaMLv/assets/images/optimized/rev-c26d8bd/askdigitalagency.com/wp-content/uploads/2024/04/techreviewer.png" alt="Trustpilot">
                        <!-- <h5>Trustpilot</h5>
                        <div class="stars">★★★★★</div> -->
                    </div>
                </div>
                <div class="col-md-3 col-6 mb-3">
                    <div class="rating-box">
                        <img src="https://cdn-ilbedhn.nitrocdn.com/gHPqezBpgLsaCHhGmBiaIcGAdKlxaMLv/assets/images/optimized/rev-c26d8bd/askdigitalagency.com/wp-content/uploads/2024/04/techreviewer.png" alt="Software Outsourcing">
                        <!-- <h5>Software Outsourcing</h5>
                        <div class="stars">★★★★★</div> -->
                    </div>
                </div>

                <!-- Second Row -->
                <div class="col-md-3 col-6 mb-3">
                    <div class="rating-box">
                        <img src="https://cdn-ilbedhn.nitrocdn.com/gHPqezBpgLsaCHhGmBiaIcGAdKlxaMLv/assets/images/optimized/rev-c26d8bd/askdigitalagency.com/wp-content/uploads/2024/04/techreviewer.png" alt="Good Firms">
                        <!-- <h5>Good Firms</h5>
                        <div class="stars">★★★★★</div> -->
                    </div>
                </div>
                <div class="col-md-3 col-6 mb-3">
                    <div class="rating-box">
                        <img src="https://cdn-ilbedhn.nitrocdn.com/gHPqezBpgLsaCHhGmBiaIcGAdKlxaMLv/assets/images/optimized/rev-c26d8bd/askdigitalagency.com/wp-content/uploads/2024/04/techreviewer.png" alt="Top Developers">
                        <!-- <h5>Top Developers</h5>
                        <div class="stars">★★★★★</div> -->
                    </div>
                </div>
                <div class="col-md-3 col-6 mb-3">
                    <div class="rating-box">
                        <img src="https://cdn-ilbedhn.nitrocdn.com/gHPqezBpgLsaCHhGmBiaIcGAdKlxaMLv/assets/images/optimized/rev-c26d8bd/askdigitalagency.com/wp-content/uploads/2024/04/techreviewer.png" alt="UpCity">
                        <!-- <h5>UpCity</h5>
                        <div class="stars">★★★★★</div> -->
                    </div>
                </div>
                <div class="col-md-3 col-6 mb-3">
                    <div class="rating-box">
                        <img src="https://cdn-ilbedhn.nitrocdn.com/gHPqezBpgLsaCHhGmBiaIcGAdKlxaMLv/assets/images/optimized/rev-c26d8bd/askdigitalagency.com/wp-content/uploads/2024/04/techreviewer.png" alt="Design Rush">
                        <!-- <h5>Design Rush</h5>
                        <div class="stars">★★★★★</div> -->
                    </div>
                </div>
            </div>
        </div>
    </section>


<section class="counter-section bg-light">
        <div class="container">
            <h2><span style="color: green; font-weight: bold;">Where Numbers</span> Speak Louder Than Words</h2>
            <p>We let the numbers do the talking</p>
            <div class="row text-center mt-4">
                <div class="col-md-3">
                    <div class="counter-box">
                        <div class="counter-number" data-target="12">0</div>
                        <p class="counter-title">Years of Excellence</p>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="counter-box">
                        <div class="counter-number" data-target="10">0</div>
                        <p class="counter-title">Team Members</p>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="counter-box">
                        <div class="counter-number" data-target="80">0</div>
                        <p class="counter-title">Keywords Ranked</p>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="counter-box">
                        <div class="counter-number" data-target="50">0</div>
                        <p class="counter-title">Successful Projects</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="Offer-section">
    <h2 class="text-center">
        <span style="color: green; font-weight: bold;">What We </span> Offer
    </h2>
    <p class="text-center">
        ASK Digital Agency offers comprehensive digital marketing services designed to deliver the right message to the right audience, driving real results for your business.
    </p>
    <div class="container py-5">
        <div class="row g-4">
            <div class="col-md-6">
                <div class="service-card p-4 shadow-sm rounded">
                    <div class="d-flex align-items-center">
                        <div class="service-icon me-2">🔍</div>
                        <h4 class="m-0">Search Engine Optimization</h4>
                    </div>
                    <p>Boost your online presence and thrive in the ever-evolving digital world with our all-encompassing digital marketing solutions...</p>
                    <div class="row">
                        <div class="col-6">
                            <ul class="list-unstyled">
                                <li>✔ Local SEO</li>
                                <li>✔ Link Building</li>
                            </ul>
                        </div>
                        <div class="col-6">
                            <ul class="list-unstyled">
                                <li>✔ Ecommerce SEO</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="service-card p-4 shadow-sm rounded">
                    <div class="d-flex align-items-center">
                        <div class="service-icon me-2">🏢</div>
                        <h4 class="m-0">Online Reputation Management</h4>
                    </div>
                    <p>Our comprehensive online brand reputation services are designed to build and maintain a positive image for your brand...</p>
                    <div class="row">
                        <div class="col-6">
                            <ul class="list-unstyled">
                                <li>✔ Reputation Management</li>
                                <li>✔ PR Marketing</li>
                            </ul>
                        </div>
                        <div class="col-6">
                            <ul class="list-unstyled">
                                <li>✔ Social Media</li>
                                <li>✔ Email Marketing</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="service-card p-4 shadow-sm rounded">
                    <div class="d-flex align-items-center">
                        <div class="service-icon me-2">🖥</div>
                        <h4 class="m-0">Web Design & Development</h4>
                    </div>
                    <p>At ASK Digital Agency, we combine creativity and technical expertise to craft user-friendly websites...</p>
                    <div class="row">
                        <div class="col-6">
                            <ul class="list-unstyled">
                                <li>✔ Ecommerce Development</li>
                                <li>✔ WordPress Development</li>
                            </ul>
                        </div>
                        <div class="col-6">
                            <ul class="list-unstyled">
                                <li>✔ Speed Optimization</li>
                                <li>✔ Shopify Development</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="service-card p-4 shadow-sm rounded">
                    <div class="d-flex align-items-center">
                        <div class="service-icon me-2">📊</div>
                        <h4 class="m-0">Performance Marketing</h4>
                    </div>
                    <p>PPC (Pay-Per-Click) advertising is a powerful tool to boost brand visibility, drive quality traffic, and accelerate lead generation...</p>
                    <div class="row">
                        <div class="col-6">
                            <ul class="list-unstyled">
                                <li>✔ Google Ads</li>
                                <li>✔ LinkedIn Marketing</li>
                            </ul>
                        </div>
                        <div class="col-6">
                            <ul class="list-unstyled">
                                <li>✔ Facebook Marketing</li>
                                <li>✔ Instagram Marketing</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="about-section-two">
    <div class="anim-icons">
        <span class="icon icon-line4"></span>
        <span class="icon icon-line5"></span>
        <span class="icon icon-arrow1 bounce-x"></span>
        <span class="icon icon-speaker zoom-one"></span>
    </div>
    <div class="auto-container">
        <div class="outer-box">
            <div class="row">
                <div class="content-column col-xl-6 col-lg-7 col-md-12 col-sm-12 order-2 wow fadeInRight" data-wow-delay="600ms">
                    <div class="inner-column">
                        <div class="sec-title">
                            <span class="sub-title">Welcome to Agency</span>
                            <h2>Leading the best digital agency in town</h2>
                            <div class="text">
                                There are many variations of simply free text passages of available but the majority have suffered alteration in some form, by injected hum randomised words which don't slightly.
                            </div>
                        </div>
                        <div class="row">
                                                        <div class="info-box col-lg-6 col-md-6">
                                <div class="inner">
                                    <h5 class="title"><i class="icon  fa fa-circle-arrow-right "></i> Digital marketing</h5>
                                    <div class="text">
                                        Knowledge of technologies rules better than anyone
                                    </div>
                                </div>
                            </div>
                                                        <div class="info-box col-lg-6 col-md-6">
                                <div class="inner">
                                    <h5 class="title"><i class="icon  fa fa-circle-arrow-right "></i> Quality results</h5>
                                    <div class="text">
                                        Knowledge of technologies rules better than anyone
                                    </div>
                                </div>
                            </div>
                                                    </div>
                        <!-- <div class="skills">
                                                        <div class="skill-item">
                                <div class="skill-header">
                                    <h5 class="skill-title">Marketing</h5>
                                </div>
                                <div class="skill-bar">
                                    <div class="bar-inner">
                                        <div class="bar progress-line" data-width="77">
                                            <div class="skill-percentage">
                                                <div class="count-box"><span class="count-text" data-speed="3000" data-stop="77">0</span>%</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                                                    </div> -->
                        <div class="bottom-box">
                            <a href="#" class="theme-btn btn-style-one hvr-dark"><span class="btn-title">Discover More</span></a>
                        </div>
                    </div>
                </div>
                <div class="image-column col-xl-6 col-lg-5 col-md-12 col-sm-12">
                    <div class="inner-column wow fadeInLeft">
                        <div class="image-box">
                            <span class="icon-dots2"></span>
                            <figure class="image-1 overlay-anim wow fadeInUp"><img src="https://demo.phpscriptpoint.com/desix/public/uploads/welcome_two_photo1_1704850420.jpg" alt=""></figure>
                            <figure class="image-2 overlay-anim wow fadeInRight"><img src="https://demo.phpscriptpoint.com/desix/public/uploads/welcome_two_photo2_1704850420.jpg" alt=""></figure>
                            <div class="exp-box">
                                <div class="inner">
                                    <i class="icon flaticon-promotion"></i>
                                    <span class="count">38+</span>
                                    <h6 class="title">Work Experience</h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


<section class="projects-section-home3">
    <div class="upper-box">
        <div class="auto-container">
            <div class="sec-title">
                <span class="sub-title">OUR PORTFOLIO</span>
                <h2>Our Recent Work</h2>
            </div>
        </div>
    </div>
    <div class="carousel-outer">
        <div class="projects-carousel owl-carousel owl-theme default-navs">
                        <div class="project-block-home3">
                <div class="image-box">
                    <figure class="image"><a href="https://demo.phpscriptpoint.com/desix/public/uploads/portfolio_1699618631.jpg" class="lightbox-image"><img src="https://demo.phpscriptpoint.com/desix/public/uploads/portfolio_1699618631.jpg" alt=""></a> </figure>
                    <div class="caption-box">
                        <h4 class="title"><a href="https://demo.phpscriptpoint.com/desix/portfolio/creative-canvas-hub">Creative Canvas Hub</a></h4>
                    </div>
                </div>
            </div>
                        <div class="project-block-home3">
                <div class="image-box">
                    <figure class="image"><a href="https://demo.phpscriptpoint.com/desix/public/uploads/portfolio_1699618801.jpg" class="lightbox-image"><img src="https://demo.phpscriptpoint.com/desix/public/uploads/portfolio_1699618801.jpg" alt=""></a> </figure>
                    <div class="caption-box">
                        <h4 class="title"><a href="https://demo.phpscriptpoint.com/desix/portfolio/innovate-craft">Innovate Craft</a></h4>
                    </div>
                </div>
            </div>
                        <div class="project-block-home3">
                <div class="image-box">
                    <figure class="image"><a href="https://demo.phpscriptpoint.com/desix/public/uploads/portfolio_1699630123.jpg" class="lightbox-image"><img src="https://demo.phpscriptpoint.com/desix/public/uploads/portfolio_1699630123.jpg" alt=""></a> </figure>
                    <div class="caption-box">
                        <h4 class="title"><a href="https://demo.phpscriptpoint.com/desix/portfolio/imagination-forge">Imagination Forge</a></h4>
                    </div>
                </div>
            </div>
                        <div class="project-block-home3">
                <div class="image-box">
                    <figure class="image"><a href="https://demo.phpscriptpoint.com/desix/public/uploads/portfolio_1699636005.jpg" class="lightbox-image"><img src="https://demo.phpscriptpoint.com/desix/public/uploads/portfolio_1699636005.jpg" alt=""></a> </figure>
                    <div class="caption-box">
                        <h4 class="title"><a href="https://demo.phpscriptpoint.com/desix/portfolio/dream-craftsman">Dream Craftsman</a></h4>
                    </div>
                </div>
            </div>
                        <div class="project-block-home3">
                <div class="image-box">
                    <figure class="image"><a href="https://demo.phpscriptpoint.com/desix/public/uploads/portfolio_1699636146.jpg" class="lightbox-image"><img src="https://demo.phpscriptpoint.com/desix/public/uploads/portfolio_1699636146.jpg" alt=""></a> </figure>
                    <div class="caption-box">
                        <h4 class="title"><a href="https://demo.phpscriptpoint.com/desix/portfolio/virtuoso-visions">Virtuoso Visions</a></h4>
                    </div>
                </div>
            </div>
                    </div>
    </div>
</section>




<section class="why-choose-us-two">
    <div class="anim-icons">
        <span class="icon icon-arrow1"></span>
    </div>
    <div class="auto-container">
        <div class="row">
            <div class="content-column col-lg-6 col-md-12">
                <div class="inner-column wow fadeInRight">
                    <div class="sec-title">
                        <i class="sub-title">Why choose us</i>
                        <h2>Building a design easy for business</h2>
                    </div>
                    <div class="row">
                                                <div class="info-box col-lg-6 col-md-6">
                            <div class="inner">
                                <div class="title-box">
                                    <i class="icon flaticon-laptop"></i>
                                    <h5 class="title">
                                        Web Growths
                                    </h5>
                                </div>
                            </div>
                        </div>
                                                <div class="info-box col-lg-6 col-md-6">
                            <div class="inner">
                                <div class="title-box">
                                    <i class="icon flaticon-graphic-design"></i>
                                    <h5 class="title">
                                        Digital solutions
                                    </h5>
                                </div>
                            </div>
                        </div>
                                                <div class="info-box col-lg-6 col-md-6">
                            <div class="inner">
                                <div class="title-box">
                                    <i class="icon flaticon-health-check"></i>
                                    <h5 class="title">
                                        Best consultancy
                                    </h5>
                                </div>
                            </div>
                        </div>
                                                <div class="info-box col-lg-6 col-md-6">
                            <div class="inner">
                                <div class="title-box">
                                    <i class="icon flaticon-teaching"></i>
                                    <h5 class="title">
                                        Expert developers
                                    </h5>
                                </div>
                            </div>
                        </div>
                                            </div>
                </div>
            </div>
            <div class="image-column col-lg-6 col-md-12">
                <div class="inner-column">
                    <div class="image-box">
                        <figure class="image anim-overlay"><img src="https://demo.phpscriptpoint.com/desix/public/uploads/why_choose_two_photo_1704886719.jpg" alt=""></figure>
                        <div class="content-box">
                            <div class="text">
                                We’re bringing latest business innovation in to the digital world
                            </div>
                            <div class="caption">Top quality marketing solutions</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


<section class="video-section-new-3">
    <div class="auto-container">
        <div class="video-box-new-3">
            <div class="bg">
                <div class="bg bg-image" style="background-image: url(https://demo.phpscriptpoint.com/desix/public/uploads/video_one_photo_1704852598.jpg)"></div>
                <div class="overlay"></div>
            </div>
            <div class="content">
                <div class="btn-box">
                    <a href="https://youtu.be/FfRoCBwkAMk?si=ZcCxuoH10Bgjq2ZJ" class="play-now" data-fancybox="gallery" data-caption=""><i class="icon fa fa-play" aria-hidden="true"></i><span class="ripple"></span></a>
                </div>
                <h2 class="title">Most Trusted Agency</h2>
            </div>
        </div>
    </div>
</section>




<section class="fun-fact-section-new-3">
    <div class="auto-container">
        <div class="outer-box">
            <div class="row">
              
            </div>
        </div>
    </div>
</section>

<section class="team-section pb-0">    
    <div class="auto-container">
        <div class="sec-title text-center">
            <span class="sub-title">MEET OUR TEAM MEMBERS</span>
            <h2>Meet the professional team<br />
behind the success</h2>
        </div>
        <div class="row">
                        <div class="team-block-two col-lg-4 col-md-6 col-sm-12 wow fadeInUp">
                <div class="inner-box">
                    <div class="info-box">
                        <h4 class="name"><a href="https://demo.phpscriptpoint.com/desix/team-member/mike-henderson">Mike Henderson</a></h4>
                        <span class="designation">Managing Director</span>
                    </div>
                    <div class="image-box">
                        <figure class="image"><a href="https://demo.phpscriptpoint.com/desix/team-member/mike-henderson"><img src="https://demo.phpscriptpoint.com/desix/public/uploads/team_member_1704650244.jpg" alt=""></a></figure> 
                        <div class="social-links">
                                                            <a href="https://www.facebook.com" target="_blank"><i class="fab fa-facebook-f"></i></a>
                                                                                        <a href="https://www.twitter.com" target="_blank"><i class="fab fa-twitter"></i></a>
                                                                                        <a href="https://www.linkedin.com" target="_blank"><i class="fab fa-linkedin-in"></i></a>
                                                                                        <a href="https://www.instagram.com" target="_blank"><i class="fab fa-instagram"></i></a>
                                                                                                            </div>
                        <span class="share-icon fas fa-plus"></span>
                    </div>
                </div>
            </div>
                        <div class="team-block-two col-lg-4 col-md-6 col-sm-12 wow fadeInUp">
                <div class="inner-box">
                    <div class="info-box">
                        <h4 class="name"><a href="https://demo.phpscriptpoint.com/desix/team-member/kevin">Kevin Martin</a></h4>
                        <span class="designation">Chief Executive Officer</span>
                    </div>
                    <div class="image-box">
                        <figure class="image"><a href="https://demo.phpscriptpoint.com/desix/team-member/kevin"><img src="https://demo.phpscriptpoint.com/desix/public/uploads/team_member_1704650135.jpg" alt=""></a></figure> 
                        <div class="social-links">
                                                            <a href="https://www.facebook.com" target="_blank"><i class="fab fa-facebook-f"></i></a>
                                                                                        <a href="https://www.twitter.com" target="_blank"><i class="fab fa-twitter"></i></a>
                                                                                        <a href="https://www.linkedin.com" target="_blank"><i class="fab fa-linkedin-in"></i></a>
                                                                                        <a href="https://www.instagram.com" target="_blank"><i class="fab fa-instagram"></i></a>
                                                                                                            </div>
                        <span class="share-icon fas fa-plus"></span>
                    </div>
                </div>
            </div>
                        <div class="team-block-two col-lg-4 col-md-6 col-sm-12 wow fadeInUp">
                <div class="inner-box">
                    <div class="info-box">
                        <h4 class="name"><a href="https://demo.phpscriptpoint.com/desix/team-member/jason-cleaver">Jason Cleaver</a></h4>
                        <span class="designation">Human Resource Manager</span>
                    </div>
                    <div class="image-box">
                        <figure class="image"><a href="https://demo.phpscriptpoint.com/desix/team-member/jason-cleaver"><img src="https://demo.phpscriptpoint.com/desix/public/uploads/team_member_1704650144.jpg" alt=""></a></figure> 
                        <div class="social-links">
                                                            <a href="https://www.facebook.com" target="_blank"><i class="fab fa-facebook-f"></i></a>
                                                                                        <a href="https://www.twitter.com" target="_blank"><i class="fab fa-twitter"></i></a>
                                                                                        <a href="https://www.linkedin.com" target="_blank"><i class="fab fa-linkedin-in"></i></a>
                                                                                        <a href="https://www.instagram.com" target="_blank"><i class="fab fa-instagram"></i></a>
                                                                                                            </div>
                        <span class="share-icon fas fa-plus"></span>
                    </div>
                </div>
            </div>
                    </div>
    </div>
</section>

<section class="clients-section">
    <div class="auto-container">
        <div class="sponsors-outer">
            <ul class="clients-carousel owl-carousel owl-theme">
                                <li class="client-block">
                                        <a href="#">
                        <img src="https://demo.phpscriptpoint.com/desix/public/uploads/client_1705167020.png" alt="">
                    </a>
                                    </li>
                                <li class="client-block">
                                        <a href="javascript:void;">
                        <img src="https://demo.phpscriptpoint.com/desix/public/uploads/client_1705167033.png" alt="">
                    </a>
                                    </li>
                                <li class="client-block">
                                        <a href="javascript:void;">
                        <img src="https://demo.phpscriptpoint.com/desix/public/uploads/client_1705167041.png" alt="">
                    </a>
                                    </li>
                                <li class="client-block">
                                        <a href="javascript:void;">
                        <img src="https://demo.phpscriptpoint.com/desix/public/uploads/client_1705167049.png" alt="">
                    </a>
                                    </li>
                                <li class="client-block">
                                        <a href="javascript:void;">
                        <img src="https://demo.phpscriptpoint.com/desix/public/uploads/client_1705167062.png" alt="">
                    </a>
                                    </li>
                            </ul>
        </div>
    </div>
</section>



<section class="news-section">
    <div class="auto-container">
        <div class="sec-title text-center">
            <span class="sub-title">FROM THE BLOG</span>
            <h2>Checkout latest news<br> updates & articles</h2>
        </div>
        <div class="row">
            @foreach($latest_posts as $post)
                <div class="news-block col-lg-4 col-md-6 col-sm-12 wow fadeInUp">
                    <div class="inner-box">
                        <div class="image-box">
                            <figure class="image">
                                <a href="{{ url('post/'.$post->slug) }}">
                                    <img src="{{ asset('storage/' . $post->photo) }}" alt="{{ $post->title }}">
                                </a>
                            </figure>
                        </div>
                        <div class="content-box">
                            <span class="date">{{ date('d M, Y', strtotime($post->created_at)) }}</span>
                            <ul class="post-info">
                                <li><i class="fa fa-user-circle"></i> by Admin</li>
                            </ul>
                            <h4 class="title">
                                <a href="{{ url('post/'.$post->slug) }}">{{ $post->title }}</a>
                            </h4>
                            <a href="{{ url('post/'.$post->slug) }}" class="read-more">
                                Read More <i class="fa fa-long-arrow-alt-right"></i>
                            </a>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
    </div>
</section>


<section class="map-section">
<div class="container faq-section">
        <h2 class="text-center mb-4">Frequently Asked Questions</h2>
        <div class="accordion" id="faqAccordion">
            <div class="accordion-item">
                <h2 class="accordion-header">
                    <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#faq1">
                        What services does ASk Digital Agency provide?
                    </button>
                </h2>
                <div id="faq1" class="accordion-collapse collapse show" data-bs-parent="#faqAccordion">
                    <div class="accordion-body">
                        ASk Digital Agency offers a wide range of digital marketing services including SEO, SEM, social media management, content marketing, web design, and more. We specialize in creating customized strategies to help businesses thrive online.
                    </div>
                </div>
            </div>
            <div class="accordion-item">
                <h2 class="accordion-header">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq2">
                        Are there any hidden fees or long-term contracts?
                    </button>
                </h2>
                <div id="faq2" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                    <div class="accordion-body">
                        Transparency is important to us. There are no hidden fees, and we don’t lock our clients into long-term contracts. We believe in earning your trust through delivering results.
                    </div>
                </div>
            </div>
            <div class="accordion-item">
                <h2 class="accordion-header">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq3">
                        Can I request a custom package tailored to my business needs?
                    </button>
                </h2>
                <div id="faq3" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                    <div class="accordion-body">
                        Yes! We offer customized packages tailored to your specific business goals and requirements.
                    </div>
                </div>
            </div>
            <div class="accordion-item">
                <h2 class="accordion-header">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq4">
                        How soon can I expect to see results from your digital marketing efforts?
                    </button>
                </h2>
                <div id="faq4" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                    <div class="accordion-body">
                        Results depend on various factors, but typically, clients start seeing improvements within a few months of implementing our strategies.
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<script>
$(document).ready(function() {
    $(".banner-carousel").owlCarousel({
        loop: true,
        margin: 10,
        nav: true, // Arrows Enable
        dots: true, // Dots Enable
        autoplay: true,
        autoplayTimeout: 5000,
        autoplayHoverPause: true,
        items: 1,
        navText: [
            "<i class='fas fa-chevron-left'></i>", 
            "<i class='fas fa-chevron-right'></i>"
        ] // Custom Arrows
    });
});
</script>

   
@include('front-end.footer')