@include('front-end.header')


<section class="page-title" style="background-image: url({{ asset('storage/'.$service->photo) }});">
    <div class="auto-container">
        <div class="title-outer">
            <h1 class="title">{{ $service->name }}</h1>
            <ul class="page-breadcrumb">
                <li><a href="{{ url('/') }}">Home</a></li>
                <li><a href="#">Services</a></li>
                <li>{{ $service->name }}</li>
            </ul>
        </div>
    </div>
</section>

<section class="services-details">
    <div class="container">
        <div class="row">
            <div class="col-xl-4 col-lg-4">
                <div class="service-sidebar">
                    <div class="sidebar-widget service-sidebar-single">
                        <div class="sidebar-service-list">
                            <ul>
                                @foreach($services as $item)
                                    <li>
                                    <a href="{{ route('service.show', $item->slug) }}" class="{{ $service->id == $item->id ? 'current' : '' }}">
                                            <i class="fas fa-angle-right"></i>
                                            <span>{{ $item->name }}</span>
                                        </a>
                                    </li>
                                @endforeach
                            </ul>
                        </div>

                        <div class="service-details-help">
                            <div class="help-shape-1"></div>
                            <div class="help-shape-2"></div>
                            <h2 class="help-title">Contact with us for any advice</h2>
                            <div class="help-icon">
                                <span class="lnr-icon-phone-handset"></span>
                            </div>
                            <div class="help-contact">
                                <p>Need help? Talk to an expert</p>
                                <a href="tel:+1 (660) 831-0044">+1 (660) 831-0044</a>
                            </div>
                        </div>

                        <div class="sidebar-widget service-sidebar-single mt-4">
                            <div class="service-sidebar-single-btn wow fadeInUp" data-wow-delay="0.5s" data-wow-duration="1200m">
                                <a href="{{ asset('storage/'.$service->pdf) }}" class="theme-btn btn-style-one d-grid">
                                    <span class="btn-title">
                                        <span class="fas fa-file-pdf"></span> Download PDF File
                                    </span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-8 col-lg-8">
                <div class="services-details__content">
                    <img src="{{ asset('storage/'.$service->banner) }}" alt="{{ $service->name }}">
                    <h3 class="mt-4">{{ $service->name }}</h3>
                    <div class="content mt-40">
                        <div class="text">
                            {!! $service->description !!}
                        </div>
                    </div>
                </div>
                <div class=" mt-25">
                        <h3>Frequently Asked Questions</h3>
                        <ul class="accordion-box wow fadeInRight">                            
                                                        <li class="accordion block">
                                <div class="acc-btn">What is app development?
                                    <div class="icon fa fa-plus"></div>
                                </div>
                                <div class="acc-content">
                                    <div class="content">
                                        <div class="text">
                                            <p>App development is the process of creating software applications for mobile devices, such as smartphones and tablets, or for web browsers. It involves a wide range of activities, from planning and design to coding and testing.</p>
                                        </div>
                                    </div>
                                </div>
                            </li>
                                                        <li class="accordion block">
                                <div class="acc-btn">Why should I hire a digital agency for app development?
                                    <div class="icon fa fa-plus"></div>
                                </div>
                                <div class="acc-content">
                                    <div class="content">
                                        <div class="text">
                                            <p>There are many benefits to hiring a digital agency for app development. Here are just a few: Expertise, Resources, Time savings, Cost savings.</p>
                                        </div>
                                    </div>
                                </div>
                            </li>
                                                        <li class="accordion block">
                                <div class="acc-btn">How do I determine the right platform for my app - iOS, Android, or both?
                                    <div class="icon fa fa-plus"></div>
                                </div>
                                <div class="acc-content">
                                    <div class="content">
                                        <div class="text">
                                            <p>The choice depends on your target audience and business goals. If you aim for a broader user base, consider both platforms. We can guide you through this decision based on your specific requirements.</p>
                                        </div>
                                    </div>
                                </div>
                            </li>
                                                        <li class="accordion block">
                                <div class="acc-btn">What role does user experience (UX) play in App Development?
                                    <div class="icon fa fa-plus"></div>
                                </div>
                                <div class="acc-content">
                                    <div class="content">
                                        <div class="text">
                                            <p>User experience is critical. A well-designed and intuitive UX enhances user satisfaction, encourages app usage, and contributes to positive reviews and ratings. We prioritize user-centric design in every stage of development.</p>
                                        </div>
                                    </div>
                                </div>
                            </li>
                                                        <li class="accordion block">
                                <div class="acc-btn">How do you ensure the security of my app and user data?
                                    <div class="icon fa fa-plus"></div>
                                </div>
                                <div class="acc-content">
                                    <div class="content">
                                        <div class="text">
                                            <p>Security is a top priority. We implement industry-standard security measures, secure coding practices, and conduct thorough testing to identify and address any vulnerabilities, ensuring the protection of your app and user data.</p>
                                        </div>
                                    </div>
                                </div>
                            </li>
                                                    </ul>
                    </div>
            </div>
        </div>
    </div>
</section>



@include('front-end.footer')
