@include('front-end.header')


<section class="page-title" style="background-image: url('{{ asset('storage/' . $post->photo) }}');">
    <div class="auto-container">
        <div class="title-outer">
            <h1 class="title">{{ $post->title }}</h1>
            <ul class="page-breadcrumb">
                <li><a href="{{ url('/') }}">Home</a></li>
                <li><a href="#">Blog</a></li>
                <li>{{ $post->title }}</li>
            </ul>
        </div>
    </div>
</section>

<section class="blog-details">
    <div class="container">
        <div class="row">
            <div class="col-xl-8 col-lg-7">
                <div class="blog-details__left">
                    <div class="blog-details__img">
                        <img src="{{ asset('storage/' . $post->photo) }}" alt="{{ $post->title }}">
                        <div class="blog-details__date">
                            <span class="day">{{ $post->created_at->format('d') }}</span>
                            <span class="month">{{ $post->created_at->format('M') }}</span>
                        </div>
                    </div>
                    <div class="blog-details__content">
                        <ul class="list-unstyled blog-details__meta">
                            <li><i class="fas fa-user-circle"></i> Admin</li>
                        </ul>
                        <p class="blog-details__text-2">
                          
                            {!! $post->description !!}
                        </p>
                    </div>
                    <div class="blog-details__bottom">
                        <p class="blog-details__tags">
                            <span>Tags</span>
                            @foreach(explode(',', $post->tags) as $tag)
                                <a href="{{ url('tag/' . trim($tag)) }}">{{ trim($tag) }}</a>
                            @endforeach
                        </p>
                    </div>
                </div>
            </div>

            <div class="col-xl-4 col-lg-5">
                <div class="sidebar">
                    <div class="sidebar__single sidebar__search">
                        <form action="{{ url('search') }}" class="sidebar__search-form" method="get">
                            <input name="search_text" type="search" placeholder="Search here" required>
                            <button type="submit"><i class="lnr-icon-search"></i></button>
                        </form>
                    </div>

                    <div class="sidebar__single sidebar__post">
                        <h3 class="sidebar__title">Latest Posts</h3>
                        <ul class="sidebar__post-list list-unstyled">
                            @foreach($latestPosts as $latest)
                                <li>
                                    <div class="sidebar__post-image">
                                        <img src="{{ asset('storage/' . $latest->photo) }}" alt="{{ $latest->title }}">
                                    </div>
                                    <div class="sidebar__post-content">
                                        <h3>
                                            <span class="sidebar__post-content-meta"><i class="fas fa-user-circle"></i> Admin</span>
                                            <a href="{{ url('post/' . $latest->slug) }}">{{ $latest->title }}</a>
                                        </h3>
                                    </div>
                                </li>
                            @endforeach
                        </ul>
                    </div>

                    <div class="sidebar__single sidebar__category">
                        <h3 class="sidebar__title mb-20">Categories</h3>
                        <ul class="sidebar__category-list list-unstyled">
                            @foreach($categories as $category)
                                <li>
                                    <a href="{{ url('category/' . $category->id) }}">{{ $category->name }}<span class="icon-right-arrow"></span></a>
                                </li>
                            @endforeach
                        </ul>
                    </div>

                    <div class="sidebar__single sidebar__tags">
                        <h3 class="sidebar__title">Tags</h3>
                        <div class="sidebar__tags-list">
                            @foreach(explode(',', $post->tags) as $tag)
                                <a href="{{ url('tag/' . trim($tag)) }}">{{ trim($tag) }}</a>
                            @endforeach
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</section>


@include('front-end.footer')