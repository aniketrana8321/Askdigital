@include('front-end.header')

<section class="page-title" style="background-image: url('{{ asset('uploads/inner-pages/' . $innerPage->photo) }}');">
    <div class="auto-container">
        <div class="title-outer">
            <h1 class="title">{{ $innerPage->title }}</h1>
            <ul class="page-breadcrumb">
                <li><a href="{{ url('/') }}">Home</a></li>
                <li><a href="#">Inner Pages</a></li>
                <li>{{ $innerPage->title }}</li>
            </ul>
        </div>
    </div>
</section>

<section class="blog-details">
    <div class="container">
        <div class="row">
            <div class="col-xl-8 col-lg-7">
                <div class="blog-details__left">
                    <div class="blog-details__img">
                        <img src="{{ asset('uploads/inner-pages/' . $innerPage->photo) }}" alt="{{ $innerPage->title }}">
                        <div class="blog-details__date">
                            <span class="day">{{ $innerPage->created_at->format('d') }}</span>
                            <span class="month">{{ $innerPage->created_at->format('M') }}</span>
                        </div>
                    </div>
                    <div class="blog-details__content">
                        <p class="blog-details__text-2">
                        {!! $innerPage->description !!}
                        </p>
                    </div>
                </div>
            </div>

            <div class="col-xl-4 col-lg-5">
                <div class="sidebar">
                    <div class="sidebar__single sidebar__post">
                        <h3 class="sidebar__title">Latest Pages</h3>
                        <ul class="sidebar__post-list list-unstyled">
                            @foreach($latestPages as $latest)
                                <li>
                                    <div class="sidebar__post-content">
                                        <h3>
                                            <a href="{{ url('inner-page/' . $latest->slug) }}">{{ $latest->title }}</a>
                                        </h3>
                                    </div>
                                </li>
                            @endforeach
                        </ul>
                    </div>

                    <div class="sidebar__single sidebar__category">
                        <h3 class="sidebar__title mb-20">Categories</h3>
                        <ul class="sidebar__category-list list-unstyled">
                            @foreach($categories as $category)
                                <li>
                                    <a href="#">{{ $category->name }}<span class="icon-right-arrow"></span></a>
                                </li>
                            @endforeach
                        </ul>
                    </div>
                </div>
            </div>

        </div>
    </div>
</section>

@include('front-end.footer')
